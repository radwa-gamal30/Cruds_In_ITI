<div style="display:inline-block;">
    <!-- I begin to speak only when I am certain what I will say is not better left unsaid. - Cato the Younger -->
    <button style="width: 70px;height: 40px; margin-bottom:5px;" class="btn btn-<?php echo e($color); ?>">
        <?php echo e($inside); ?>

    </button>
</div><?php /**PATH C:\xampp\htdocs\dashboard\project01\resources\views/components/button.blade.php ENDPATH**/ ?>