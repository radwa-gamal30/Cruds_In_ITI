<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>All tracks</title>
</head>
<body>
    <table class="table table-hover" style="width:80vw; margin: 30px 50px;">
        <thead>
          <tr>
            <th scope="col">Id</th>
            <th scope="col">name</th>
            <th scope="col">location</th>
            <th scope="col">duration</th>
            <th scope="col">AC</th>
          </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $tracks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $track): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th ><?php echo e($track->id); ?></th>
            <td><?php echo e($track->name); ?></td>
            <td><?php echo e($track->location); ?></td>
            <td><?php echo e($track->duration); ?></td>
        
            <td class="col">
              <a href="<?php echo e(route('tracks.trackview',$track->id)); ?>"><button class="btn btn-success">view</button></a>
              
              <form action="<?php echo e(route('tracks.destroy', $track->id)); ?>" method="POST" style="display:inline;">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger">Delete</button>
            </form>
            </td>
            
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       
        </tbody>
      </table>
</body>
</html><?php /**PATH C:\xampp\htdocs\dashboard\project01\resources\views/tracks.blade.php ENDPATH**/ ?>