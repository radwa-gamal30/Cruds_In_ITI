<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>All Stuents</title>
</head>
<body>
    <table class="table table-hover">
        <thead>
          <tr>
            <th scope="col">Id</th>
            <th scope="col">name</th>
            <th scope="col">email</th>
            <th scope="col">Grade</th>
            <th scope="col">Gender</th>
            <th scope="col">address</th>
            <th scope="col">image</th>
            <th scope="col">AC</th>
          </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo e($student->$id); ?></th>
            <td><?php echo e($student->name); ?></td>
            <td><?php echo e($student->email); ?></td>
            <td><?php echo e($student->grade); ?></td>
            <td><?php echo e($student->gender); ?></td>
            <td><?php echo e($student->address); ?></td>
            <td><?php echo e($student->image); ?></td>
            <td><a href=""><button class="btn btn-warnning">view</button></td>
            
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       
        </tbody>
      </table>
</body>
</html><?php /**PATH C:\xampp\htdocs\dashboard\project01\resources\views/students_Data.blade.php ENDPATH**/ ?>