<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>All tracks</title>
</head>
<body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
      <a class="navbar-brand" href="#"></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('students.index')); ?>">Students</a>
          </li>
          <li class="nav-item">
            <a  class="nav-link active" aria-current="page" href="<?php echo e(route('tracks.index')); ?>">Tracks</a>
          </li>
          
        </ul>
      </div>
    </div>
  </nav>
    <table class="table table-hover" style="width:85vw; margin: 30px 50px;">
        <thead>
          <tr>
            <th scope="col">Id</th>
            <th scope="col">name</th>
            <th scope="col">location</th>
            <th scope="col">duration</th>
            <th scope="col">AC</th>
          </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $tracks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $track): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th ><?php echo e($track->id); ?></th>
            <td><?php echo e($track->name); ?></td>
            <td><img src="<?php echo e($track->logo); ?>" alt="track-logo" style="width: 30%; height:auto; "></td>

            <td><?php echo e($track->location); ?></td>
            <td><?php echo e($track->duration); ?></td>

        
            <td class="col">
              <a href="<?php echo e(route('tracks.trackview',$track->id)); ?>"><button class="btn btn-success">view</button></a>
              
              <form action="<?php echo e(route('tracks.destroy', $track->id)); ?>" method="POST" style="display:inline;">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>

                <button type="submit" class="btn btn-danger">Delete</button>
            </form>
     
          <a href="<?php echo e(route('tracks.createtrack',$track->id)); ?>"><button class="btn btn-info">create</button></a>
          <a href="<?php echo e(route('tracks.edit_track',$track->id)); ?>"><button class="btn btn-dark">update</button></a>
            </td>
            
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       
        </tbody>
      </table>
</body>
</html><?php /**PATH C:\xampp\htdocs\dashboard\project01\resources\views/tracks/tracks.blade.php ENDPATH**/ ?>